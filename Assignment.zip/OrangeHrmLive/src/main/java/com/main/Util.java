package com.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Util extends BaseClass {

	public void initializeWorkBook(String fileDir) throws IOException {
		File file = new File(fileDir);
		fis = new FileInputStream(file);
		wb = new XSSFWorkbook(fis);

	}

	@SuppressWarnings("deprecation")
	public HashMap<String, Object> getData(String sheetName) throws IOException {
		List<String> headerName = new ArrayList<String>();
		HashMap<String, Object> valueMap = new HashMap<String, Object>();
		try {
			Sheet sh = wb.getSheet(sheetName);
			int rowCount = sh.getPhysicalNumberOfRows();

			for (int header = 0; header < 1; header++) {
				Row row = sh.getRow(header);
				for (int c = 0; c < row.getLastCellNum(); c++) {
					headerName.add(row.getCell(c).getStringCellValue());
				}
			}

			for (int r = 1; r < rowCount; r++) {
				Row row = sh.getRow(r);
				for (int c = 0; c < row.getLastCellNum(); c++) {
					switch (row.getCell(c).getCellTypeEnum()) {
					case NUMERIC: {
						valueMap.put(headerName.get(c), row.getCell(c).getNumericCellValue());
						break;
					}
					default: {
						valueMap.put(headerName.get(c), row.getCell(c).getStringCellValue());
					}
					}
				}
			}
		} catch (Exception e) {
			System.out.println("Exception while getting data from Excel");
		} finally {
			wb.close();
		}
		return valueMap;
	}

	@SuppressWarnings("deprecation")
	public boolean writeExcelData(String sheetName, String colName, String message) throws IOException {
		this.initializeWorkBook(ExcelLocation);
		Sheet sh = wb.getSheet(sheetName);
		List<String> headerName = new ArrayList<String>();
		for (int header = 0; header < 1; header++) {
			Row row = sh.getRow(header);
			for (int c = 0; c < row.getLastCellNum(); c++) {
				headerName.add(row.getCell(c).getStringCellValue());
			}
		}
		Cell cell;
		try {
			cell = sh.getRow(1).createCell(headerName.indexOf(colName));
		} catch (Exception e1) {
			cell= sh.getRow(1).getCell(headerName.indexOf(colName));
			cell.setCellType(CellType.BLANK);
		}

		cell.setCellValue(message);
		FileOutputStream fos = new FileOutputStream(ExcelLocation);
		wb.write(fos);
		fos.close();
		return false;

	}

	public void closeExcelStream() throws IOException {
		fis.close();
	}
}
