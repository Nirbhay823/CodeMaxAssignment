package com.main;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass{
	public static WebDriver driver;
	public static Workbook wb;
	public static FileInputStream fis;
	public static String ExcelLocation = "D:\\Selenium\\Seleniumbatch_October2019-develop\\OrangeHrmLive\\Datasheet\\Data.xlsx";

	public void initialize(){	
		String sProjectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", sProjectPath + "\\Library\\chromedriver.exe");
		//ChromeOptions options = new ChromeOptions();
		//options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
		//options.setExperimentalOption("debuggerAddress", "localhost:9014");
		driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	}
}
