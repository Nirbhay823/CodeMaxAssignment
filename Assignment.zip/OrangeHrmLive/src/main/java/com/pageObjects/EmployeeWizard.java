package com.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.main.BaseClass;

public class EmployeeWizard extends BaseClass {
	public EmployeeWizard(WebDriver session) {
		driver = session;
		PageFactory.initElements(driver, this);
		}
	
    public void employeewizard(String AccountsClerk, String region, String FTE, String TD) throws InterruptedException{
	JavascriptExecutor js = (JavascriptExecutor)driver;
	
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver,30);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Job Title')]//preceding-sibling::div")));
	driver.findElement(By.xpath("//label[contains(text(),'Job Title')]//preceding-sibling::div")).click();
	Thread.sleep(5000);
	
	WebElement elementregion = driver.findElement(By.xpath("//label[contains(text(),'Region')]//preceding-sibling::div//li//span[contains(text(),'"+region+"')]"));
	js.executeScript("arguments[0].click();", elementregion);

	
	WebElement elementFTE = driver.findElement(By.xpath("//label[contains(text(),'FTE')]//preceding-sibling::div//li//span[contains(text(),'"+FTE+"')]"));
	js.executeScript("arguments[0].click();", elementFTE);
	
	WebElement elementTD = driver.findElement(By.xpath("//label[contains(text(),'Temporary Department')]//preceding-sibling::div//li//span[contains(text(),'"+TD+"')]"));
	js.executeScript("arguments[0].click();", elementTD);
	
	
	WebElement elementsave = driver.findElement(By.xpath("//button[text()='Save']"));
	js.executeScript("arguments[0].click();", elementsave);
}
    

}


