package com.pageObjects;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.main.BaseClass;
import com.main.Util;

public class Leave extends BaseClass{
	
	Util test= new Util();
	
	public Leave(WebDriver session){
		driver = session;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH, using="//a//span[text()='Leave']")
	private static WebElement leavetab;
	
	@FindBy(how = How.XPATH, using="//input[@id='employee_value']")
	private static WebElement EmpName;
		
	@FindBy(how = How.XPATH, using="//input[@id='from']")
	private static WebElement fromdate;
	
	
	public void ApplyingLeave(String name, String from, String to, String leave) throws InterruptedException, IOException{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		leavetab.click();
		WebElement assignLeave = driver.findElement(By.xpath("//a[@id='menu_leave_assignLeave']//span[text()='Assign Leave']"));
		js.executeScript("arguments[0].click();", assignLeave);
		Thread.sleep(10000);
		
		EmpName.sendKeys(name);
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='employee_dropdown']//span[contains(text(),'"+name+"')]")));
		WebElement hovervalue = driver.findElement(By.xpath("//div[@id='employee_dropdown']//span[contains(text(),'"+name+"')]"));
		Actions actions = new Actions(driver);
		actions.moveToElement(hovervalue);
		actions.click().build().perform();
		Thread.sleep(5000);
		
		WebElement leavetype = driver.findElement(By.xpath("//label[contains(text(),'Leave Type')]//preceding-sibling::div//ul//child::li//span[contains(text(),'"+leave+"')]"));
		js.executeScript("arguments[0].click();", leavetype);
		
		fromdate.sendKeys(from);
		
		WebElement tilldate = driver.findElement(By.xpath("//button[text()='Assign']"));
		tilldate.sendKeys(to);
		
		WebElement buttons = driver.findElement(By.xpath("//button[text()='Assign']"));
		js.executeScript("arguments[0].click();", buttons);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='toast-container']//following-sibling::div")));
		WebElement text = driver.findElement(By.xpath("//div[@id='toast-container']//following-sibling::div"));
		String message = text.getText();
		System.out.println(message);
		test.writeExcelData("Sheet2", "Result", message);
		
		
	}
 
}
