package com.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.main.BaseClass;

public class LoginPage extends BaseClass {

	public LoginPage(WebDriver session) {
		driver = session;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.ID, using = "txtUsername")
	private static WebElement userName;

	@FindBy(how = How.ID, using = "txtPassword")
	private static WebElement password;

	@FindBy(how = How.ID, using = "btnLogin")
	private static WebElement login;

	public void signIn(String name, String passcode) {
		userName.sendKeys(name);
		password.sendKeys(passcode);
		login.click();
		
	}
}
