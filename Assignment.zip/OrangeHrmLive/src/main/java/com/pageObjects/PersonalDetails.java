package com.pageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.main.BaseClass;

public class PersonalDetails extends BaseClass {
	     public PersonalDetails(WebDriver session) {
			driver = session;
			PageFactory.initElements(driver, this);
			
		}
	
	@FindBy(how = How.XPATH, using = "//input[@id='5']")
	 private static WebElement hobbies;
	
	@FindBy(how = How.XPATH, using = "//button[text()='Next']")
	 private static WebElement button;
	
	public void  personal(String bd, String hobbie, String maritalStatus, String gender, String bloodgroup) throws InterruptedException{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement birth = driver.findElement(By.xpath("//input[@id='emp_birthday']"));
		birth.sendKeys(bd);
		
		WebElement elementMaritalStatus = driver.findElement(By.xpath("//label[contains(text(),'Marital Status')]//preceding-sibling::div//li//span[contains(text(),'"+maritalStatus+"')]"));
		js.executeScript("arguments[0].click();", elementMaritalStatus);
		
		WebElement elementgender = driver.findElement(By.xpath("//label[contains(text(),'Gender')]//preceding-sibling::div//li//span[contains(text(),'"+gender+"')]"));
		js.executeScript("arguments[0].click();", elementgender);
		
		WebElement elementbloodgroup = driver.findElement(By.xpath("//label[contains(text(),'Blood Group')]//preceding-sibling::div//li//span[contains(text(),'"+bloodgroup+"')]"));
		js.executeScript("arguments[0].click();", elementbloodgroup);
			
		hobbies.sendKeys(hobbie);
		
		js.executeScript("arguments[0].click();", button);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		
	}
	
	
	
	

	
	   

}

