package com.pageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.main.BaseClass;

public class PimPage extends BaseClass{
     
	public PimPage(WebDriver session) {
		driver = session;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'PIM')]")
	private static WebElement PIMSelect;
	
	@FindBy(how = How.XPATH, using = "//body/div[@id='wrapper']/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[4]/ul[1]/li[2]/div[1]/ul[1]/li[3]/a[1]/span[2]")
	private static WebElement EmpWizard;
	
	@FindBy (how = How.XPATH, using = "//input[@id='firstName']")
	private static WebElement firstName;
	
	@FindBy (how = How.XPATH, using= "//input[@id='middleName']")
	private static WebElement middleName;
	
	@FindBy (how = How.XPATH, using= "//input[@id='lastName']")
	private static WebElement lastName;
	
	@FindBy (how = How.XPATH, using= "//input[@id='employeeId']")
	private static WebElement EmpId;
	
	@FindBy (how = How.XPATH, using = "//body/div[@id='addEmployeeModal']/form[@id='pimAddEmployeeForm']/div[1]/div[1]/materializecss-decorator[2]/div[1]/sf-decorator[1]/div[1]/sf-decorator[2]/div[1]/div[1]/input[1]")
	private static WebElement selectDrop;
	
	@FindBy (how = How.XPATH, using = "//div[@id='location_inputfileddiv']//following-sibling::div//child::li[3]//child::span")
	private static WebElement dropdownselect;
	
	
	public void PIMpage(String FN, String MN) throws InterruptedException{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", PIMSelect);
		js.executeScript("arguments[0].click();", EmpWizard);

		Thread.sleep(10000);
		
		firstName.sendKeys(FN);
		middleName.sendKeys(MN);
		
		
	}
	public void PIMpage2(String LN, String EID, String locationDropValue) throws InterruptedException{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		lastName.sendKeys(LN);
		EmpId.clear();
		EmpId.sendKeys(EID);
		//selectDrop.click();
		WebElement dropValue=driver.findElement(By.xpath("//label[contains(text(),'Location')]//preceding-sibling::div//li//span[contains(text(),'"+locationDropValue+"')]"));
		js.executeScript("arguments[0].click();", dropValue);
		Thread.sleep(5000);
		WebElement next = driver.findElement(By.xpath("//a[@id='systemUserSaveBtn']"));
		js.executeScript("arguments[0].click();", next);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
		
	}
	
	
	
	



