package com.main;

import java.io.IOException;
import java.util.HashMap;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.pageObjects.EmployeeWizard;
import com.pageObjects.Leave;
import com.pageObjects.LoginPage;
import com.pageObjects.PersonalDetails;
import com.pageObjects.PimPage;

public class NewTest extends BaseClass {
	Util test = new Util();
	HashMap<String, Object> sheet1Data;
	HashMap<String, Object> sheet2Data;

	@Test()
	public void TC_01() throws IOException, InterruptedException {
		LoginPage login = new LoginPage(driver);
		driver.navigate().to(sheet1Data.get("URL").toString());

		login.signIn(sheet1Data.get("UserName").toString(), sheet1Data.get("Password").toString());

		System.out.println("Login Successfull");

		 PimPage PIM = new PimPage(driver);
		 PIM.PIMpage(sheet2Data.get("Firstname").toString(),
		 sheet2Data.get("MiddleName").toString());
		 PIM.PIMpage2(sheet2Data.get("LastName").toString(),
	     sheet2Data.get("EmployeeId").toString(),sheet2Data.get("LocationDropValue").toString());
		
		 PersonalDetails PD = new PersonalDetails(driver);
		 PD.personal(sheet2Data.get("DOB").toString(),sheet2Data.get("Hobbies").toString(),sheet2Data.get("MaritalStatus").toString(),sheet2Data.get("Gender").toString(),sheet2Data.get("BloodGroup").toString());
		
		 EmployeeWizard EW = new EmployeeWizard(driver);
		 EW.employeewizard(sheet2Data.get("jobTitle").toString(),
		 sheet2Data.get("RegionSelect").toString(),sheet2Data.get("FTESelect").toString(),sheet2Data.get("TemporaryDepartment").toString());

		Leave leaves = new Leave(driver);
		leaves.ApplyingLeave(sheet2Data.get("Firstname").toString(), sheet2Data.get("FromDate").toString(),
				sheet2Data.get("ToDate").toString(), sheet2Data.get("LeaveType").toString());
		

	}

	@BeforeTest
	public void openBrowser() throws IOException {
		this.initialize();
		test.initializeWorkBook(ExcelLocation);
		sheet1Data = test.getData("Sheet1");
		sheet2Data = test.getData("Sheet2");
		test.closeExcelStream();
	}

	@AfterTest
	public void closeBrowser() throws IOException {
		driver.quit();
	}

}
